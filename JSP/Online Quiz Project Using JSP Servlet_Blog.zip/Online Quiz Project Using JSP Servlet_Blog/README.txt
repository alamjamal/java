--------------READ ME ---------------------------

1. The code references to quizzes file , make sure you have quizzes folder in C drive. ( C:\quizzes)
   If you have extracted quizzes to some other location than you have to change the location in the code class CreateDOM.java accordingly
   
2. I have used MySQL database , if you don`t have MySQL or working with some other database make sure you change it accordingly 
   in the CreateDatabaseConnectionFactory.java
   
3. Make Sure you have JSTL jar and MySQL jdbc driver under lib folder of WEB-INF   

4. If you have any suggestions or questions , mail me at alammahtab08@gmail.com   
   
   
